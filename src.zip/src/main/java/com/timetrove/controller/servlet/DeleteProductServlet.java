package com.timetrove.controller.servlet;

import com.timetrove.controller.dao.ProductDAO;
import com.timetrove.model.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;


@WebServlet("/DeleteProductServlet")
public class DeleteProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productId = request.getParameter("productId");

        if (productId == null || productId.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/AddProductPageServlet");
            return;
        }

        ProductDAO productDAO = new ProductDAO();
        Product product = productDAO.getProductById(productId); // Get product to get image filename

        // Delete product from DB
        boolean deleted = productDAO.deleteProduct(productId);

        // Delete image file if product was deleted and image exists
        if (deleted && product != null && product.getImage() != null) {
            String imagePath = getServletContext().getRealPath("/images/" + product.getImage());
            File imageFile = new File(imagePath);
            if (imageFile.exists()) {
                imageFile.delete();
            }
        }

        response.sendRedirect(request.getContextPath() + "/AddProductPageServlet");
    }

    // Disable GET method to avoid 405 error
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED, "GET method is not supported for deletion.");
    }
}
