package com.timetrove.controller.servlet;

import com.timetrove.controller.dao.UserDAO;
import com.timetrove.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        System.out.println(">>> Login attempt: username = " + username + ", password = " + password);

        UserDAO userDAO = new UserDAO();
        User user = userDAO.login(username, password);

        if (user != null) {
            System.out.println(">>> Login successful. Role = " + user.getRole());

            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            if ("Admin".equalsIgnoreCase(user.getRole())) {
                response.sendRedirect(request.getContextPath() + "/userCount");
            } else {
                response.sendRedirect(request.getContextPath() + "/pages/UserHome.jsp");
            }
        } else {
            System.out.println(">>> Login failed. Invalid credentials.");
            response.sendRedirect(request.getContextPath() + "/pages/login.jsp?error=true");
        }
    }
}
