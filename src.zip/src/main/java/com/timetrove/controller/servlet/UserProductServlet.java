package com.timetrove.controller.servlet;

import com.timetrove.controller.dao.ProductDAO;
import com.timetrove.model.Product;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/UserProductServlet")
public class UserProductServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Product> products = new ProductDAO().getAllProducts();
        request.setAttribute("products", products);

        // 👇 Pass success message if present
        String success = request.getParameter("success");
        if (success != null) {
            request.setAttribute("success", success);
        }

        request.getRequestDispatcher("pages/UserProduct.jsp").forward(request, response);
    }
}
